const path = require('path');

const express = require('express');

const router = express.Router();

const enrollController = require('../controllers/enroll-controller');

router.get('/', enrollController.enrollPage);

module.exports = router;