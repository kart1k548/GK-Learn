exports.enrollPage = (req,res,next) =>{
    res.render('viewer/enroll',{
        pageTitle: "Enroll"
    });
   
}