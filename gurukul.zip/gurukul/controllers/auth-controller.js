exports.getSignupPage = (req,res,next) =>{
  res.render('auth/signup',{
      pageTitle: "signup"
  });
};

exports.getLoginPage = (req,res,next) =>{
  res.render('auth/login',{
      pageTitle: "login"
  });
};
