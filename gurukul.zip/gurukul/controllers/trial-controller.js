exports.trialPage = (req,res,next) =>{
    res.render('viewer/trial',{
        pageTitle: "GK Trial",
        isAuthenticated: req.session.isLoggedIn
    });
}