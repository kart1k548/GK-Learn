exports.homePage = (req,res,next) =>{
    res.render('viewer/home',{
        pageTitle: "Home"
    });
   
}