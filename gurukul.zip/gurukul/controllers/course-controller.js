exports.getCoursePage = (req,res,next) =>{
    res.render('viewer/course',{
        pageTitle: " Course",
        isAuthenticated: req.session.isLoggedIn
    });  
};

exports.getEnrollPage = (req,res,next) =>{
    res.render('viewer/enroll',{
        pageTitle: "Enroll",
        isAuthenticated: req.session.isLoggedIn
    });  
};