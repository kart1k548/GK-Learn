exports.coursePage = (req,res,next) =>{
    res.render('viewer/course',{
        pageTitle: " Course"
    });
   
}