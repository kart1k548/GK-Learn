exports.getCoursePage = (req,res,next) =>{
    res.render('viewer/course',{
        pageTitle: " Course"
    });  
};

exports.getEnrollPage = (req,res,next) =>{
    res.render('viewer/enroll',{
        pageTitle: "Enroll"
    });  
};