exports.contactPage = (req,res,next) =>{
    res.render('viewer/contact',{
        pageTitle: "Contact"
    });
   
}