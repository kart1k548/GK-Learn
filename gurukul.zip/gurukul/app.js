const express = require('express');

const path = require('path');
//const mongoose =require('mongoose');
const app = express();

//app.use(express.static(__dirname + '/public'));
app.set("view engine", "ejs");
app.set("views", "views");

//mongoose.connect('mongodb+srv://bk:bk123@bk-cluster.rp2i3.mongodb.net/<dbname>?retryWrites=true&w=majority')
//.then(()=>{
 //   console.log("connected to database");
//});



const aboutRoutes = require('./routes/about');
const courseRoutes = require('./routes/course');
const homeRoutes = require('./routes/home');
const contactRoutes = require('./routes/contact');
const authRoutes = require('./routes/auth');


app.use(express.static(path.join(__dirname,'public')));

app.use('/course',courseRoutes);
app.use('/about',aboutRoutes);
app.use('/contact',contactRoutes);
app.use('/auth', authRoutes);
app.use('/',homeRoutes);


app.listen(5000,()=>{
    console.log('Listening to 5000');
});
